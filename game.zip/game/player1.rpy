screen playerOneRole:
    frame:
        xsize 600
        ysize 500
        xoffset 335
        # yoffset 200
        background None
        has vbox
        
        vbox:
            xoffset 225
            yoffset 200
            imagebutton:
                idle Solid("#FFF", xsize=128, ysize=64)
                hover Solid("#ff8303", xsize=128, ysize=64)
                action [Show("playerRole1"), Hide("playerOneRole")]
            text "GET ROLE" size 24 color "#fff" 

screen playerRole1:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset 335
        background None
        has vbox
        vbox:
            xoffset 225
            yoffset 200
            text "Your role is: [roles['Player 1']]" color "#fff" size 24 xoffset -100
            if roles['Player 1'] == "Guest":
                textbutton "Okay." action [Show("gameplayWalkPlayer1"), Hide("playerRole1")]
            elif roles['Player 1'] == "Master Vampire":
                textbutton "Okay." action [Show("player1_ListSelect"), Hide("playerRole1")] #xoffset 0 yalign 0.65 

screen gameplayWalkPlayer1:
    frame:
        xsize 600
        ysize 500
        xoffset 600
        yoffset 250
        
        background None
        
        has vbox

        if player1Background == "#000080":
            text "Main Hub" xoffset -50
            hbox:
                textbutton "<-" action SetVariable("player1Background", "#800000") xoffset -200
                textbutton "->" action SetVariable("player1Background", "#00801c") xoffset 150
            textbutton "^\n |" action SetVariable("player1Background", "#804900") yoffset -300

        elif player1Background == "#800000":
            text "Left Wing" xoffset -50
            textbutton "->" action SetVariable("player1Background", "#000080") xoffset 200
            
        elif player1Background == "#00801c":
            text "Right Wing" xoffset -50
            textbutton "<-" action SetVariable("player1Background", "#000080") xoffset -200

        elif player1Background == "#804900":
            text "Balcony" xoffset -50
            textbutton "|\nv" action SetVariable("player1Background", "#000080") yoffset 100

screen player1_ListSelect:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset 335
        background None
        has vbox

        vbox:
            xoffset 225
            yoffset 150

            if readyToVote['Player 1'] == False:
                textbutton "Player 2" action [Show("player1_confirmScreens"), Hide("player1_ListSelect"), ToggleDict(player1, "selectPlayer2Vampire", True)]

                textbutton "Player 3" action [Show("player1_confirmScreens"), Hide("player1_ListSelect"), ToggleDict(player1, "selectplayer3Vampire", True)]
                
                textbutton "Player 4" action [Show("player1_confirmScreens"), Hide("player1_ListSelect"), ToggleDict(player1, "selectPlayer4Vampire", True)]

            if readyToVote['Player 1'] == True:
                textbutton "Player 2" action [Show("player1_confirmScreens"), Hide("player1_ListSelect"), ToggleDict(player1, "selectPlayer2Exile", True)]

                textbutton "Player 3" action [Show("player1_confirmScreens"), Hide("player1_ListSelect"), ToggleDict(player1, "selectPlayer3Exile", True)]
                
                textbutton "Player 4" action [Show("player1_confirmScreens"), Hide("player1_ListSelect"), ToggleDict(player1, "selectPlayer4Exile", True)]

screen player1_confirmScreens:
    if roles['Player 1'] == ("Master Vampire" or "Vampire") and readyToVote['Player 1'] == False:
        frame:
            xsize 600
            ysize 500
            # yoffset 557
            xoffset 335
            background None
            has vbox

            if readyToVote['Player 1'] == False:
                
                if player1['selectplayer3Vampire'] == True:
                    text "Turn Player 3 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player1_minigame1"), Hide("player1_confirmScreens"), Notify("hi"), ToggleDict(player1, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player1_ListSelect"), Notify("NO!!!"), Hide("player1_confirmScreens"), ToggleDict(player1, "selectplayer3Vampire", False)]

                if player1['selectPlayer2Vampire'] == True:
                    text "Turn Player 2 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player1_minigame1"), Hide("player1_confirmScreens"), Notify("hi"), ToggleDict(player1, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player1_ListSelect"), Notify("NO!!!"), Hide("player1_confirmScreens"), ToggleDict(player1, "selectPlayer2Vampire", False)]

                if player1['selectPlayer4Vampire'] == True:
                    text "Turn Player 4 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player1_minigame1"), Hide("player1_confirmScreens"), Notify("hi"), ToggleDict(player1, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player1_ListSelect"), Notify("NO!!!"), Hide("player1_confirmScreens"), ToggleDict(player1, "selectPlayer4Vampire", False)]

    if readyToVote['Player 1'] == True:
        frame:
            xsize 600
            ysize 500
            # yoffset 557
            xoffset 335
            background None
            has vbox

            if player1['selectPlayer2Exile'] == True:
                text "Exile Player 2?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player1_confirmScreens"), Notify("hi"), SetVariable("playerTally3", playerTally3 + 1), ToggleDict(playersVoted, "Player 1", True)]

                    textbutton "No" action [Show("player1_ListSelect"), Notify("NO!!!"), Hide("player1_confirmScreens"), ToggleDict(player1, "selectPlayer2Exile", False)]

            if player1['selectPlayer3Exile'] == True:
                text "Exile Player 3?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player1_confirmScreens"), Notify("hi"), SetVariable("playerTally3", playerTally3 + 1), ToggleDict(playersVoted, "Player 1", True)]

                    textbutton "No" action [Show("player1_ListSelect"), Notify("NO!!!"), Hide("player1_confirmScreens"), ToggleDict(player1, "selectPlayer3Exile", False)]

            if player1['selectPlayer4Exile'] == True:
                text "Exile Player 4?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player1_confirmScreens"), Notify("hi"), SetVariable("playerTally4", playerTally4 + 1), ToggleDict(playersVoted, "Player 1", True)]

                    textbutton "No" action [Show("player1_ListSelect"), Notify("NO!!!"), Hide("player1_confirmScreens"), ToggleDict(player1, "selectPlayer4Exile", False)]

screen player1_minigame1:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 550 ypos 50
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player1_minigame2"), Hide("player1_minigame1")]

screen player1_minigame2:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 550 ypos 100
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player1_minigame3"), Hide("player1_minigame2")]

screen player1_minigame3:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 600 ypos 50
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player1_successTurning"), Hide("player1_minigame3")]

screen player1_successTurning:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset 335
        background None
        has vbox

        if player1['selectPlayer3Vampire']:
            $ roles['Player 3'] = "Vampire"
            text "Successfully turned Player 3!" xoffset 50 yoffset 150

        if player1['selectPlayer2Vampire']:
            $ roles['Player 2'] = "Vampire"
            text "Successfully turned Player 2!" xoffset 50 yoffset 150

        if player1['selectPlayer4Vampire']:
            $ roles['Player 4'] = "Vampire"
            text "Successfully turned Player 4!" xoffset 50 yoffset 150

        textbutton "End day." action [Show("endDayText"), Hide("player1_successTurning"), ToggleDict(endDayPlayers, "Player 3", True)] xoffset 225 yoffset 150 at buttonFadeIn


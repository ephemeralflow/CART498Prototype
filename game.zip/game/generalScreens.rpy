screen endDayText:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        text "Check the main screen!" xoffset 100 yoffset 200 # at buttonFadeIn

    timer 1.0 action [Show("endDayRealText"), Hide("endDayText")]

screen endDayRealText:
    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        hbox:
            yoffset -350

            text "Check the main screen!" xoffset 100 # at buttonFadeIn # player 1
            text "Check the main screen!" xoffset 350 # at buttonFadeIn # player 2
        
        hbox:
            yoffset 200
            text "Check the main screen!" xoffset 100 # at buttonFadeIn # player 3
            text "Check the main screen!" xoffset 350 # at buttonFadeIn # player 4

    if playersVoted['Player 1'] == True and playersVoted['Player 2'] == True and playersVoted['Player 3'] == True and playersVoted['Player 4'] == True:
        timer 2.0 action [Notify("meow")]
    else:
        timer 2.0 action [Show("player1ReadyVote"), Show("player2ReadyVote"), Show("player3ReadyVote"), Show("player4ReadyVote"), Hide("endDayRealText")]

screen endOfDate:
    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if playersVoted['Player 1'] == True:
            text "You have voted..." xoffset 100 yoffset -350 
        
        if playersVoted['Player 2'] == True:
            text "You have voted..." xoffset 750 yoffset -350
        
        if playersVoted['Player 3'] == True:
            text "You have voted..." xoffset 100 yoffset 200
        
        if playersVoted['Player 4'] == True:
            text "You have voted..." xoffset 750 yoffset 200
        
    if playersVoted['Player 1'] == True and playersVoted['Player 2'] == True and playersVoted['Player 3'] == True and playersVoted['Player 4'] == True:
        timer 5.0 action [Show("endDayRealText"), Hide("endOfDate")]

screen player1ReadyVote:

    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if readyToVote['Player 1'] == False or readyToVote['Player 2'] == False or readyToVote['Player 3'] == False or readyToVote['Player 4'] == False:
            if player1['ready'] == False:
                textbutton "I'm ready to continue." action [Show("player1_ListSelect"), Hide("player1ReadyVote"), ToggleDict(player1, "ready", True)], ToggleDict(readyToVote, "Player 1", True) xoffset 100 yoffset -350 

        elif readyToVote['Player 2'] == True and readyToVote['Player 3'] == True and readyToVote['Player 4'] == True:
            textbutton "I'm ready to continue." action [Show("player1_ListSelect"), Hide("endDaySelect"), ToggleDict(readyToVote, "Player 1", True)] xoffset 100 yoffset -350 # at buttonFadeIn

screen player2ReadyVote:

    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if readyToVote['Player 1'] == False or readyToVote['Player 2'] == False or readyToVote['Player 3'] == False or readyToVote['Player 4'] == False:
            if player2['ready'] == False:
                textbutton "I'm ready to continue." action [Show("player2_ListSelect"), Hide("player2ReadyVote"), ToggleDict(player2, "ready", True)], ToggleDict(readyToVote, "Player 2", True) xoffset 750 yoffset -350

        elif readyToVote['Player 1'] == True and readyToVote['Player 3'] == True and readyToVote['Player 4'] == True:
            textbutton "I'm ready to continue." action [Show("player2_ListSelect"), Hide("player2ReadyVote"), ToggleDict(readyToVote, "Player 2", True)] xoffset 750 yoffset -350 # at buttonFadeIn

screen player3ReadyVote:

    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if readyToVote['Player 1'] == False or readyToVote['Player 2'] == False or readyToVote['Player 3'] == False or readyToVote['Player 4'] == False:
            if player3['ready'] == False:
                textbutton "I'm ready to continue." action [Show("player3_ListSelect"), Hide("player3ReadyVote"), ToggleDict(player3, "ready", True)], ToggleDict(readyToVote, "Player 3", True) xoffset 100 yoffset 200

        elif readyToVote['Player 1'] == True and readyToVote['Player 2'] == True and readyToVote['Player 4'] == True:
            textbutton "I'm ready to continue." action [Show("player3_ListSelect"), Hide("player3ReadyVote"), ToggleDict(readyToVote, "Player 3", True)] xoffset 100 yoffset 200 # at buttonFadeIn

screen player4ReadyVote:

    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if readyToVote['Player 1'] == False or readyToVote['Player 2'] == False or readyToVote['Player 3'] == False or readyToVote['Player 4'] == False:
            if player4['ready'] == False:
                textbutton "I'm ready to continue." action [Show("player4_ListSelect"), Hide("player4ReadyVote"), ToggleDict(player4, "ready", True)], ToggleDict(readyToVote, "Player 4", True) xoffset 750 yoffset 200

        elif readyToVote['Player 1'] == True and readyToVote['Player 3'] == True and readyToVote['Player 2'] == True:
            textbutton "I'm ready to continue." action [Show("player4_ListSelect"), Hide("player4ReadyVote"), ToggleDict(readyToVote, "Player 4", True)] xoffset 750 yoffset 200 # at buttonFadeIn

screen endDaySelectPlayer:
    if roles['Player 3'] == "Master Vampire":
        frame:
            xsize 600
            ysize 500
            yoffset 557
            xoffset 335
            background None
            has vbox

            vbox:
                xoffset 225
                yoffset 150
                textbutton "Player 1" action [Show("player3_confirmScreens"), Hide("endDaySelectPlayer"), ToggleVariable("player1SelectExile", True)]
                textbutton "Player 2" action Notify("ho")
                textbutton "Player 4" action Notify("he")
        

screen mainScreenToggle:
    zorder 100
    imagebutton:
        xpos 125 ypos 50
        idle Solid("#FFF", xsize=64, ysize=64)
        hover Solid("#ff8303", xsize=64, ysize=64)
        action [ToggleScreen("mainScreen")]
    text "Toggle Main Screen"

screen mainScreen:
    zorder 99
    add "#008080"

    if endDayPlayers ["Player 3"] == False and playersVoted["Player 3"] == False:
        text "hi!" xalign 0.5 yalign 0.5
    if endDayPlayers["Player 3"] == True and playersVoted["Player 3"] == False:
        vbox:
            xalign 0.5 
            yalign 0.5
            text "Someone got turned!" xalign 0.5 yalign 0.5
            text "Figure out who are the vampires..." xalign 0.5 yalign 0.5

    if playersVoted["Player 3"] == True:
        vbox:
            xalign 0.5 
            yalign 0.5

            $ highestTally = max(playerTally1, playerTally2, playerTally3, playerTally4)

            if highestTally == playerTally1:
                text "Player 1 got exiled..." xalign 0.5 yalign 0.5
                if roles['Player 1'] == "Master Vampire":
                    text "Player 1 was the Master Vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 1'] == "Vampire":
                    text "Player 1 was a vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 1'] == "Guest":
                    text "Player 1 was a guest!" xalign 0.5 yalign 0.5

            elif highestTally == playerTally2:
                text "Player 2 got exiled..." xalign 0.5 yalign 0.5
                if roles['Player 2'] == "Master Vampire":
                    text "Player 2 was the Master Vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 2'] == "Vampire":
                    text "Player 2 was a vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 2'] == "Guest":
                    text "Player 2 was a guest!" xalign 0.5 yalign 0.5

            elif highestTally == playerTally3:
                text "Player 3 got exiled..." xalign 0.5 yalign 0.5
                if roles['Player 3'] == "Master Vampire":
                    text "Player 3 was the Master Vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 3'] == "Vampire":
                    text "Player 3 was a vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 3'] == "Guest":
                    text "Player 3 was a guest!" xalign 0.5 yalign 0.5

            elif highestTally == playerTally4:
                text "Player 4 got exiled..." xalign 0.5 yalign 0.5
                if roles['Player 4'] == "Master Vampire":
                    text "Player 4 was the Master Vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 4'] == "Vampire":
                    text "Player 4 was a vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 4'] == "Guest":
                    text "Player 4 was a guest!" xalign 0.5 yalign 0.5

        timer 3.0 action [Show("prototypeFinish")]


screen prototypeFinish:
    zorder 99
    add "#030303"

    vbox:
        xalign 0.5
        yalign 0.5
        text "That is the end of the prototype!\n" xalign 0.5 yalign 0.5
        
        text "{a=https://docs.google.com/forms/d/e/1FAIpQLSeyegvaFgHwXSxaRTChXpHXdDFKz3L-5FnC8iTqvRNlCDuzDg/viewform?usp=header}If you can, leave your feedback here.{/a}" xalign 0.5 yalign 0.5

screen role_grid_screen():
    if not all_can_ready:
        timer 3.0 action SetVariable("all_can_ready", True)

    python:
        all_players_ready = all(p["players_ready"] for p in players.values())

    # When all players are ready, start a 2-second timer to unlock the map controls
    if all_players_ready and not map_controls_unlocked:
        timer 2.0 action SetVariable("map_controls_unlocked", True)

    frame:
        xfill True
        yfill True
        background None

        frame:
            xalign 0.5
            yalign 0.5
            xmaximum 1450  # Max width of the inner box
            ymaximum 820   # Max height of the inner box
            xfill True
            yfill True
            padding (30, 30)
            background None
            add "window_frame.png" xalign 0.5 yalign 0.5
            vbox:
                spacing 20
                xalign 0.5

                grid 2 2:
                    xfill True
                    yfill True
                    spacing 20  # Spacing between the four player cards
                    
                    use player_card("Player 1")
                    use player_card("Player 2")
                    use player_card("Player 3")
                    use player_card("Player 4")

                null height 10
                
                if not all_can_ready:
                    text "Wait 3 seconds for ready buttons to unlock..." size 14 color "#aaa" xalign 0.5
                elif not all_players_ready:
                    text "Waiting for all players to click 'I'm Ready'..." size 14 color "#ffcc00" xalign 0.5
                elif not map_controls_unlocked:
                    text "All ready! Preparing map..." size 14 color "#00e676" bold True xalign 0.5
                else:
                    null
# screen player_locations_sidebar():
#     frame:
#         xalign 0.98
#         yalign 0.5
#         xsize 220
#         ysize 380
#         background "#18181ee8"
#         padding (15, 15)

#         vbox:
#             xfill True
#             spacing 10
            
#             text "Player Locations" size 16 color "#ffcc00" bold True xalign 0.5 text_align 0.5
#             null height 5

#             for p_key, p_data_item in players.items():
#                 vbox:
#                     spacing 2
#                     text "[p_key]" size 14 color "#ffffff" bold True xalign 0.0
#                     text "Room: [p_data_item['location']]" size 12 color "#aaaaaa" xalign 0.0
#                     null height 6

screen information_button:
    grid 1 4:
        xpos 20
        ypos 20
        spacing 20
        vbox:
            spacing 5
            imagebutton:
                idle Solid("#393e46", xsize=128, ysize=128)
                hover Solid("#00adb5", xsize=128, ysize=128)
                action ToggleScreen("welcome_screen")
            text "WELCOME" size 24 color "#eee" xalign 0.5

        vbox:
            spacing 5
            imagebutton:
                idle Solid("#393e46", xsize=128, ysize=128)
                hover Solid("#00adb5", xsize=128, ysize=128)
                action ToggleScreen("information_tutorial")
            text "INFO" size 24 color "#eee" xalign 0.5

        vbox:
            spacing 5
            imagebutton:
                idle Solid("#393e46", xsize=128, ysize=128)
                hover Solid("#00adb5", xsize=128, ysize=128)
                action ToggleScreen("feedback_screen")
            text "FEEDBACK" size 24 color "#eee" xalign 0.5

        vbox:
            spacing 5
            imagebutton:
                idle Solid("#393e46", xsize=128, ysize=128)
                hover Solid("#00adb5", xsize=128, ysize=128)
                action ToggleScreen("main_television")
            text "MAIN SCREEN" size 24 color "#eee" xalign 0.5
        

screen information_tutorial():
    frame:
        xalign 0.5
        yalign 0.5
        padding (40, 40)
        add "instructions.png" xalign 0.5 yalign 0.5
        background None

        vbox:
            spacing 15
            xalign 0.5
            yalign 0.5
            xmaximum 400
            
            text "ROLES" size 32 color "#ffffff" bold True xalign 0.5

            null height 10

            vbox:
                spacing 5
                xalign 0.5
                
                text "MASTER VAMPIRE" size 18 color "#ff0000" bold True xalign 0.5
                text "Every round, this role can select a player who shares the same room as them and attempt to turn them into a vampire." size 14 color "#dddddd" xalign 0.5

            vbox:
                spacing 5
                xalign 0.5
                
                text "VAMPIRE" size 18 color "#ff0000" bold True xalign 0.5
                text "A victim of the MASTER VAMPIRE. Will be stripped away of all ability but will win with the vampire." size 14 color "#dddddd" xalign 0.5

            vbox:
                spacing 5
                xalign 0.5
                
                text "CULTIST" size 18 color "#ff0000" bold True xalign 0.5
                text "Will win with the vampire." size 14 color "#dddddd" xalign 0.5

            vbox:
                spacing 5
                xalign 0.5
                
                text "HOST" size 18 color "#ff0000" bold True xalign 0.5
                text "With the VIEW MAP button on the corner of the screen, this role can see where every role is at any time." size 14 color "#dddddd" xalign 0.5

            vbox:
                spacing 5
                xalign 0.5
                
                text "PRIEST" size 18 color "#ff0000" bold True xalign 0.5
                text "Similar to the MASTER VAMPIRE, this role can select a player to protect for a round from the vampire as long as they share a room. They can also skip a round and exorcise, turning a (non-master) vampire back into their previous role." size 14 color "#dddddd" xalign 0.5

            null height 20

            # Close button to exit the screen
            textbutton "Close" action [ToggleScreen("welcome_screen"), Hide("information_tutorial")] xalign 0.5

screen feedback_screen():
    frame:
        xalign 0.5
        yalign 0.5
        padding (40, 40)
        add "instructions.png" xalign 0.5 yalign 0.5
        background None

        vbox:
            spacing 15
            xalign 0.5
            yalign 0.5
            xmaximum 400
            
            text "Thank you for checking out the prototype!" size 32 color "#ffffff" bold True xalign 0.5

            null height 10

            vbox:
                spacing 5
                xalign 0.5
                
                text "If you have the time, it would mean a lot if you could fill this {a=https://docs.google.com/forms/d/e/1FAIpQLSemgQXjF3qdwSUNbDDVCNS9yaO0DW9mgXo7XbKkDv65lbWtHg/viewform?usp=header}feedback form!{/a}" size 18 color "#fff" xalign 0.5

            null height 20

            # Close button to exit the screen
            textbutton "Close" action [ToggleScreen("feedback_screen"), Hide("information_tutorial")] xalign 0.5

screen welcome_screen():
    frame:
        xalign 0.5
        yalign 0.5
        padding (40, 40)
        add "instructions.png" xalign 0.5 yalign 0.5
        background None

        add "BittenBall_Logo.png" xalign 0.5 yalign 0.18

        vbox:
            spacing 15
            xalign 0.5
            yalign 0.7
            xmaximum 400
            
            text "WELCOME TO THE BITTEN BALL GAME PROTOTYPE" size 32 color "#ffffff" bold True xalign 0.5

            null height 10

            vbox:
                spacing 5
                xalign 0.5
                
                text "This is an early prototype on waht to expect of the gameplay loop. Not all buttons work perfectly and some of the visuals are placeholders for the sake of the prototype.\n\nYour goal is to get a feel of the game and figure out if it contains any game breaking bugs." size 18 color "#fff" xalign 0.5
                text "" size 18 color "#fff" xalign 0.5
                # text "Every round, this role can select a player who shares the same room as them and attempt to turn them into a vampire." size 14 color "#dddddd" xalign 0.5

            

            null height 20

            # Close button to exit the screen
            textbutton "GO BACK TO" action [ToggleScreen("welcome_screen"), Hide("information_tutorial")] xalign 0.5 ypos -50
            textbutton "GAME" action [ToggleScreen("welcome_screen"), Hide("information_tutorial")] xalign 0.5 ypos -60

screen live_vampire_counter():
    python:
        # Get all players who are currently alive (not Exiled)
        alive_players = [p for p in players.values() if p.get("role") != "Exiled"]
        
        # Count Vampires (includes both normal and master vampires)
        vampire_count = sum(1 for p in alive_players if p.get("role") == "Vampire")
        
        # Count Survivors / Non-Vampires (Guests, Priests, etc.)
        survivor_count = sum(1 for p in alive_players if p.get("role") != "Vampire")

    frame:
        xalign 0.5
        yalign 0.2
        padding (16, 8)
        background None
        
        hbox:
            spacing 15
            
            # Left Side: Survivors
            hbox:
                spacing 5
                text "Survivors:" size 64 color "#ffffff" bold True yalign 0.5
                text "[survivor_count]" size 64 color "#00e676" bold True yalign 0.5
                
            # Divider
            text "|" size 14 color "#666666" yalign 0.5
            
            # Right Side: Vampires
            hbox:
                spacing 5
                text "Vampires:" size 64 color "#ffffff" bold True yalign 0.5
                text "[vampire_count]" size 64 color "#ff4444" bold True yalign 0.5

screen main_television():

    add "window_frame.png" xalign 0.5 yalign 0.5

    python:
        # Check current game progression states safely from store variables
        started = globals().get("director_started", False)
        
        # Check if ALL players have revealed their roles (opened their letters)
        letters_opened = all(p.get("roles_revealed", False) for p in players.values()) if 'players' in globals() else False
        
        # Calculate live survivor vs vampire counts for the counter phase
        alive_players = [p for p in players.values() if p.get("role") != "Exiled"] if 'players' in globals() else []
        vampire_count = sum(1 for p in alive_players if p.get("role") == "Vampire")
        survivor_count = sum(1 for p in alive_players if p.get("role") != "Vampire")

    frame:
        xfill True
        yfill True
        background None


        if not started:
            frame:
                xalign 0.5
                yalign 0.5
                padding (40, 40)
                add "instructions.png" xalign 0.5 yalign 0.5
                background None

                add "BittenBall_Logo.png" xalign 0.5 yalign 0.18

                vbox:
                    spacing 15
                    xalign 0.5
                    yalign 0.5
                    xmaximum 400
                    
                    text "WELCOME TO THE BITTEN BALL GAME PROTOTYPE" size 32 color "#ffffff" bold True xalign 0.5

                    null height 10

                    vbox:
                        spacing 5
                        xalign 0.5
                        
                        text "This is an early prototype on waht to expect of the gameplay loop. Not all buttons work perfectly and some of the visuals are placeholders for the sake of the prototype.\n\nYour goal is to get a feel of the game and figure out if it contains any game breaking bugs." size 18 color "#fff" xalign 0.5
                        text "" size 18 color "#fff" xalign 0.5
                        # text "Every round, this role can select a player who shares the same room as them and attempt to turn them into a vampire." size 14 color "#dddddd" xalign 0.5

            vbox:
                xalign 0.5
                yalign 0.7
                spacing 25
                # text "THE VAMPIRE MANOR" size 36 color "#ce1212" bold True xalign 0.5 text_align 0.5
                textbutton "START GAME":
                    action [SetVariable("director_started", True), Hide("main_television")]
                    xalign 0.5
                    padding (20, 12)
                    background "#8b0000"
                    hover_background "#ff0000"
                    text_size 18

        elif not letters_opened:
            vbox:
                xalign 0.5
                yalign 0.5
                spacing 15
                text "Waiting for all players to open their letters..." size 22 color "#ffcc00" bold True xalign 0.5 text_align 0.5
                text "Look at the 4 player screens and click 'Reveal Role' on each." size 14 color "#aaa" xalign 0.5 text_align 0.5


        else:
            fixed:
                xfill True
                yfill True

                # --- TOP BAR: LIVE SURVIVOR VS VAMPIRE COUNTER ---
                frame:
                    xalign 0.5
                    yalign 0.02
                    padding (16, 8)
                    background "#1a1a2eee"
                    
                    hbox:
                        spacing 15
                        hbox:
                            spacing 5
                            text "Survivors:" size 14 color "#ffffff" bold True yalign 0.5
                            text "[survivor_count]" size 16 color "#00e676" bold True yalign 0.5
                        text "|" size 14 color "#666666" yalign 0.5
                        hbox:
                            spacing 5
                            text "Vampires:" size 14 color "#ffffff" bold True yalign 0.5
                            text "[vampire_count]" size 16 color "#ff4444" bold True yalign 0.5

                # --- NOTIFICATION / TEXT REFLECTIONS (Centered during Exile) ---
                fixed:
                    xfill True
                    yfill True

                    vbox:
                        xalign 0.5
                        yalign (0.5 if globals().get("exile_phase_active", False) else 0.15)
                        spacing 15

                        # Reflects when entering the ball or general phase status
                        if not globals().get("map_controls_unlocked", False) and not globals().get("exile_results_active", False) and globals().get("bite_result") is None:
                            text "Entering the Manor Ball..." size 24 color "#ce1212" italic True xalign 0.5 text_align 0.5

                        # Reflects turn-end & voting phase narrative text
                        if globals().get("bite_result") is not None and globals().get("night_phase_step", 0) >= 1 and not globals().get("exile_results_active", False):
                            vbox:
                                xalign 0.5
                                spacing 10
                                text "There must be a vampire among us..." size 32 color "#ffffff" bold True italic True xalign 0.5 text_align 0.5
                                text "Figure out who is the traitor." size 20 color "#ff4444" bold True xalign 0.5 text_align 0.5

                        # Reflects exile results when active
                        if globals().get("exile_results_active", False):
                            python:
                                exile_res = globals().get("exiled_player_result", "None")
                            if exile_res == "None":
                                text "The votes were split. No one was exiled today." size 22 color "#ffcc00" bold True xalign 0.5 text_align 0.5
                            else:
                                text "[exile_res] has been exiled!" size 22 color "#ff4444" bold True xalign 0.5 text_align 0.5

                # --- 4-CUBE MAP LAYOUT REFLECTION (Hidden during Exile Phase) ---
                if globals().get("map_controls_unlocked", False) and not globals().get("exile_phase_active", False) and not globals().get("exile_results_active", False):
                    fixed:
                        xalign 0.5
                        yalign 0.55
                        xysize (1100, 350)

                        grid 3 2:
                            xalign 0.5
                            yalign 0.5
                            spacing 15
                            
                            # --- ROW 1 ---
                            null
                            frame:
                                xysize (330, 125)
                                background "#5c4e1dbf"
                                text "Balcony" size 20 color "#fff" bold True align (0.5, 0.5)
                            null

                            # --- ROW 2 ---
                            frame:
                                xysize (330, 125)
                                background "#5c1d1dbf"
                                text "Left Wing" size 20 color "#fff" bold True align (0.5, 0.5)
                            frame:
                                xysize (330, 125)
                                background "#1b1216bf"
                                text "Main Hub" size 20 color "#fff" bold True align (0.5, 0.5)
                            frame:
                                xysize (330, 125)
                                background "#1d5c2abf"
                                text "Right Wing" size 20 color "#fff" bold True align (0.5, 0.5)











    
    
screen endDayText:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        text "Check the main screen!" xoffset 100 yoffset 200 # at buttonFadeIn

    timer 1.0 action [Show("endDayRealText"), Hide("endDayText")]

screen endDayRealText:
    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        hbox:
            yoffset -350

            text "Check the main screen!" xoffset 100 # at buttonFadeIn # player 1
            text "Check the main screen!" xoffset 350 # at buttonFadeIn # player 2
        
        hbox:
            yoffset 200
            text "Check the main screen!" xoffset 100 # at buttonFadeIn # player 3
            text "Check the main screen!" xoffset 350 # at buttonFadeIn # player 4

    if playersVoted['Player 1'] == True and playersVoted['Player 2'] == True and playersVoted['Player 3'] == True and playersVoted['Player 4'] == True:
        timer 2.0 action [Notify("meow")]
    else:
        timer 2.0 action [Show("player1ReadyVote"), Show("player2ReadyVote"), Show("player3ReadyVote"), Show("player4ReadyVote"), Hide("endDayRealText")]

screen endOfDate:
    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if playersVoted['Player 1'] == True:
            text "You have voted..." xoffset 100 yoffset -350 
        
        if playersVoted['Player 2'] == True:
            text "You have voted..." xoffset 750 yoffset -350
        
        if playersVoted['Player 3'] == True:
            text "You have voted..." xoffset 100 yoffset 200
        
        if playersVoted['Player 4'] == True:
            text "You have voted..." xoffset 750 yoffset 200
        
    if playersVoted['Player 1'] == True and playersVoted['Player 2'] == True and playersVoted['Player 3'] == True and playersVoted['Player 4'] == True:
        timer 5.0 action [Show("endDayRealText"), Hide("endOfDate")]

screen player1ReadyVote:

    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if readyToVote['Player 1'] == False or readyToVote['Player 2'] == False or readyToVote['Player 3'] == False or readyToVote['Player 4'] == False:
            if player1['ready'] == False:
                textbutton "I'm ready to continue." action [Show("player1_ListSelect"), Hide("player1ReadyVote"), ToggleDict(player1, "ready", True)], ToggleDict(readyToVote, "Player 1", True) xoffset 100 yoffset -350 

        elif readyToVote['Player 2'] == True and readyToVote['Player 3'] == True and readyToVote['Player 4'] == True:
            textbutton "I'm ready to continue." action [Show("player1_ListSelect"), Hide("endDaySelect"), ToggleDict(readyToVote, "Player 1", True)] xoffset 100 yoffset -350 # at buttonFadeIn

screen player2ReadyVote:

    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if readyToVote['Player 1'] == False or readyToVote['Player 2'] == False or readyToVote['Player 3'] == False or readyToVote['Player 4'] == False:
            if player2['ready'] == False:
                textbutton "I'm ready to continue." action [Show("player2_ListSelect"), Hide("player2ReadyVote"), ToggleDict(player2, "ready", True)], ToggleDict(readyToVote, "Player 2", True) xoffset 750 yoffset -350

        elif readyToVote['Player 1'] == True and readyToVote['Player 3'] == True and readyToVote['Player 4'] == True:
            textbutton "I'm ready to continue." action [Show("player2_ListSelect"), Hide("player2ReadyVote"), ToggleDict(readyToVote, "Player 2", True)] xoffset 750 yoffset -350 # at buttonFadeIn

screen player3ReadyVote:

    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if readyToVote['Player 1'] == False or readyToVote['Player 2'] == False or readyToVote['Player 3'] == False or readyToVote['Player 4'] == False:
            if player3['ready'] == False:
                textbutton "I'm ready to continue." action [Show("player3_ListSelect"), Hide("player3ReadyVote"), ToggleDict(player3, "ready", True)], ToggleDict(readyToVote, "Player 3", True) xoffset 100 yoffset 200

        elif readyToVote['Player 1'] == True and readyToVote['Player 2'] == True and readyToVote['Player 4'] == True:
            textbutton "I'm ready to continue." action [Show("player3_ListSelect"), Hide("player3ReadyVote"), ToggleDict(readyToVote, "Player 3", True)] xoffset 100 yoffset 200 # at buttonFadeIn

screen player4ReadyVote:

    frame:
        xsize 1000
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if readyToVote['Player 1'] == False or readyToVote['Player 2'] == False or readyToVote['Player 3'] == False or readyToVote['Player 4'] == False:
            if player4['ready'] == False:
                textbutton "I'm ready to continue." action [Show("player4_ListSelect"), Hide("player4ReadyVote"), ToggleDict(player4, "ready", True)], ToggleDict(readyToVote, "Player 4", True) xoffset 750 yoffset 200

        elif readyToVote['Player 1'] == True and readyToVote['Player 3'] == True and readyToVote['Player 2'] == True:
            textbutton "I'm ready to continue." action [Show("player4_ListSelect"), Hide("player4ReadyVote"), ToggleDict(readyToVote, "Player 4", True)] xoffset 750 yoffset 200 # at buttonFadeIn

screen endDaySelectPlayer:
    if roles['Player 3'] == "Master Vampire":
        frame:
            xsize 600
            ysize 500
            yoffset 557
            xoffset 335
            background None
            has vbox

            vbox:
                xoffset 225
                yoffset 150
                textbutton "Player 1" action [Show("player3_confirmScreens"), Hide("endDaySelectPlayer"), ToggleVariable("player1SelectExile", True)]
                textbutton "Player 2" action Notify("ho")
                textbutton "Player 4" action Notify("he")
        

screen mainScreenToggle:
    zorder 100
    imagebutton:
        xpos 125 ypos 50
        idle Solid("#FFF", xsize=64, ysize=64)
        hover Solid("#ff8303", xsize=64, ysize=64)
        action [ToggleScreen("mainScreen")]
    text "Toggle Main Screen"

screen mainScreen:
    zorder 99
    add "#008080"

    if endDayPlayers ["Player 3"] == False and playersVoted["Player 3"] == False:
        text "hi!" xalign 0.5 yalign 0.5
    if endDayPlayers["Player 3"] == True and playersVoted["Player 3"] == False:
        vbox:
            xalign 0.5 
            yalign 0.5
            text "Someone got turned!" xalign 0.5 yalign 0.5
            text "Figure out who are the vampires..." xalign 0.5 yalign 0.5

    if playersVoted["Player 3"] == True:
        vbox:
            xalign 0.5 
            yalign 0.5

            $ highestTally = max(playerTally1, playerTally2, playerTally3, playerTally4)

            if highestTally == playerTally1:
                text "Player 1 got exiled..." xalign 0.5 yalign 0.5
                if roles['Player 1'] == "Master Vampire":
                    text "Player 1 was the Master Vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 1'] == "Vampire":
                    text "Player 1 was a vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 1'] == "Guest":
                    text "Player 1 was a guest!" xalign 0.5 yalign 0.5

            elif highestTally == playerTally2:
                text "Player 2 got exiled..." xalign 0.5 yalign 0.5
                if roles['Player 2'] == "Master Vampire":
                    text "Player 2 was the Master Vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 2'] == "Vampire":
                    text "Player 2 was a vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 2'] == "Guest":
                    text "Player 2 was a guest!" xalign 0.5 yalign 0.5

            elif highestTally == playerTally3:
                text "Player 3 got exiled..." xalign 0.5 yalign 0.5
                if roles['Player 3'] == "Master Vampire":
                    text "Player 3 was the Master Vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 3'] == "Vampire":
                    text "Player 3 was a vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 3'] == "Guest":
                    text "Player 3 was a guest!" xalign 0.5 yalign 0.5

            elif highestTally == playerTally4:
                text "Player 4 got exiled..." xalign 0.5 yalign 0.5
                if roles['Player 4'] == "Master Vampire":
                    text "Player 4 was the Master Vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 4'] == "Vampire":
                    text "Player 4 was a vampire!" xalign 0.5 yalign 0.5
                elif roles['Player 4'] == "Guest":
                    text "Player 4 was a guest!" xalign 0.5 yalign 0.5

        timer 3.0 action [Show("prototypeFinish")]


screen prototypeFinish:
    zorder 99
    add "#030303"

    vbox:
        xalign 0.5
        yalign 0.5
        text "That is the end of the prototype!\n" xalign 0.5 yalign 0.5
        
        text "{a=https://docs.google.com/forms/d/e/1FAIpQLSeyegvaFgHwXSxaRTChXpHXdDFKz3L-5FnC8iTqvRNlCDuzDg/viewform?usp=header}If you can, leave your feedback here.{/a}" xalign 0.5 yalign 0.5

        
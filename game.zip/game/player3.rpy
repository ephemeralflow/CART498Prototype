screen playerThreeRole:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox
        
        vbox:
            xoffset 225
            yoffset 200
            imagebutton:
                idle Solid("#FFF", xsize=128, ysize=64)
                hover Solid("#ff8303", xsize=128, ysize=64)
                action [Show("playerRole3"), Hide("playerThreeRole")]
            text "GET ROLE" size 24 color "#fff" 

screen playerRole3:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox
        vbox:
            xoffset 225
            yoffset 200
            text "Your role is: [roles['Player 3']]" color "#fff" size 24 xoffset -100
            textbutton "Okay." action [Show("player3_ListSelect"), Hide("playerRole3")] xoffset 0 yalign 0.65 at buttonFadeIn

screen player3_ListSelect:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        vbox:
            xoffset 225
            yoffset 150

            if readyToVote['Player 3'] == False:
                textbutton "Player 1" action [Show("player3_confirmScreens"), Hide("player3_ListSelect"), ToggleDict(player3, "selectPlayer1Vampire", True)]

                textbutton "Player 2" action [Show("player3_confirmScreens"), Hide("player3_ListSelect"), ToggleDict(player3, "selectPlayer2Vampire", True)]
                
                textbutton "Player 4" action [Show("player3_confirmScreens"), Hide("player3_ListSelect"), ToggleDict(player3, "selectPlayer4Vampire", True)]

            if readyToVote['Player 3'] == True:
                textbutton "Player 1" action [Show("player3_confirmScreens"), Hide("player3_ListSelect"), ToggleDict(player3, "selectPlayer1Exile", True)]

                textbutton "Player 2" action [Show("player3_confirmScreens"), Hide("player3_ListSelect"), ToggleDict(player3, "selectPlayer2Exile", True)]
                
                textbutton "Player 4" action [Show("player3_confirmScreens"), Hide("player3_ListSelect"), ToggleDict(player3, "selectPlayer4Exile", True)]

screen player3_confirmScreens:
    if roles['Player 3'] == "Master Vampire" and readyToVote['Player 3'] == False:
        frame:
            xsize 600
            ysize 500
            yoffset 557
            xoffset 335
            background None
            has vbox

            if readyToVote['Player 3'] == False:
                
                if player3['selectPlayer1Vampire'] == True:
                    text "Turn Player 1 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player3_minigame1"), Hide("player3_confirmScreens"), Notify("hi"), ToggleDict(player3, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player3_ListSelect"), Notify("NO!!!"), Hide("player3_confirmScreens"), ToggleDict(player3, "selectPlayer1Vampire", False)]

                if player3['selectPlayer2Vampire'] == True:
                    text "Turn Player 2 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player3_minigame1"), Hide("player3_confirmScreens"), Notify("hi"), ToggleDict(player3, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player3_ListSelect"), Notify("NO!!!"), Hide("player3_confirmScreens"), ToggleDict(player3, "selectPlayer2Vampire", False)]

                if player3['selectPlayer4Vampire'] == True:
                    text "Turn Player 4 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player3_minigame1"), Hide("player3_confirmScreens"), Notify("hi"), ToggleDict(player3, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player3_ListSelect"), Notify("NO!!!"), Hide("player3_confirmScreens"), ToggleDict(player3, "selectPlayer4Vampire", False)]

    if readyToVote['Player 3'] == True:
        frame:
            xsize 600
            ysize 500
            yoffset 557
            xoffset 335
            background None
            has vbox

            if player3['selectPlayer1Exile'] == True:
                text "Exile Player 1?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player3_confirmScreens"), Notify("hi"), SetVariable("playerTally1", playerTally1 + 1), ToggleDict(playersVoted, "Player 3", True)]

                    textbutton "No" action [Show("player3_ListSelect"), Notify("NO!!!"), Hide("player3_confirmScreens"), ToggleDict(player3, "selectPlayer1Exile", False)]

            if player3['selectPlayer2Exile'] == True:
                text "Exile Player 2?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player3_confirmScreens"), Notify("hi"), SetVariable("playerTally2", playerTally3 + 1), ToggleDict(playersVoted, "Player 3", True)]

                    textbutton "No" action [Show("player3_ListSelect"), Notify("NO!!!"), Hide("player3_confirmScreens"), ToggleDict(player3, "selectPlayer2Exile", False)]

            if player3['selectPlayer4Exile'] == True:
                text "Exile Player 4?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player3_confirmScreens"), Notify("hi"), SetVariable("playerTally4", playerTally4 + 1), ToggleDict(playersVoted, "Player 3", True)]

                    textbutton "No" action [Show("player3_ListSelect"), Notify("NO!!!"), Hide("player3_confirmScreens"), ToggleDict(player3, "selectPlayer4Exile", False)]

screen player3_minigame1:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 550 ypos 50
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player3_minigame2"), Hide("player3_minigame1")]

screen player3_minigame2:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 550 ypos 100
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player3_minigame3"), Hide("player3_minigame2")]

screen player3_minigame3:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 600 ypos 50
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player3_successTurning"), Hide("player3_minigame3")]

screen player3_successTurning:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset 335
        background None
        has vbox

        if player3['selectPlayer1Vampire']:
            $ roles['Player 1'] = "Vampire"
            text "Successfully turned Player 1!" xoffset 50 yoffset 150

        if player3['selectPlayer2Vampire']:
            $ roles['Player 2'] = "Vampire"
            text "Successfully turned Player 2!" xoffset 50 yoffset 150

        if player3['selectPlayer4Vampire']:
            $ roles['Player 4'] = "Vampire"
            text "Successfully turned Player 4!" xoffset 50 yoffset 150

        textbutton "End day." action [Show("endDayText"), Hide("player3_successTurning"), ToggleDict(endDayPlayers, "Player 3", True), ToggleVariable("vampireTurnAttempt", True)] xoffset 225 yoffset 150 at buttonFadeIn


screen playerFourRole:
    frame:
        xsize 600
        ysize 500
        xoffset 1000
        yoffset 557
        background None
        has vbox
        
        vbox:
            xoffset 225
            yoffset 200
            imagebutton:
                idle Solid("#FFF", xsize=128, ysize=64)
                hover Solid("#ff8303", xsize=128, ysize=64)
                action [Show("playerRole4"), Hide("playerFourRole")]
            text "GET ROLE" size 24 color "#fff" 

screen playerRole4:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset 1000
        background None
        has vbox
        vbox:
            xoffset 225
            yoffset 200
            text "Your role is: [roles['Player 4']]" color "#fff" size 24 xoffset -100
            if roles['Player 4'] == "Guest":
                textbutton "Okay." action [Show("gameplayWalkplayer4"), Hide("playerRole4")] 
            elif roles['Player 4'] == "Master Vampire":
                textbutton "Okay." action [Show("player4_ListSelect"), Hide("playerRole4")] #xoffset 0 yalign 0.65 

screen gameplayWalkplayer4:
    frame:
        xsize 600
        ysize 500
        xoffset 1250
        yoffset 800
        
        background None
        
        has vbox

        if player4Background == "#000080":
            text "Main Hub" xoffset -50
            hbox:
                textbutton "<-" action SetVariable("player4Background", "#800000") xoffset -200
                textbutton "->" action SetVariable("player4Background", "#00801c") xoffset 150
            textbutton "^\n |" action SetVariable("player4Background", "#804900") yoffset -300

        elif player4Background == "#800000":
            text "Left Wing" xoffset -50
            textbutton "->" action SetVariable("player4Background", "#000080") xoffset 200
            
        elif player4Background == "#00801c":
            text "Right Wing" xoffset -50
            textbutton "<-" action SetVariable("player4Background", "#000080") xoffset -200

        elif player4Background == "#804900":
            text "Balcony" xoffset -50
            textbutton "|\nv" action SetVariable("player4Background", "#000080") yoffset 100

screen player4_ListSelect:
    frame:
        xsize 600
        ysize 500
        yoffset 557
        xoffset 1000
        background None
        has vbox

        vbox:
            xoffset 225
            yoffset 150

            if readyToVote['Player 4'] == False:
                textbutton "Player 1" action [Show("player4_confirmScreens"), Hide("player4_ListSelect"), ToggleDict(player4, "selectPlayer1Vampire", True)]

                textbutton "Player 2" action [Show("player4_confirmScreens"), Hide("player4_ListSelect"), ToggleDict(player4, "selectplayer2Vampire", True)]
                
                textbutton "Player 3" action [Show("player4_confirmScreens"), Hide("player4_ListSelect"), ToggleDict(player4, "selectPlayer3Vampire", True)]

            if readyToVote['Player 4'] == True:
                textbutton "Player 1" action [Show("player4_confirmScreens"), Hide("player4_ListSelect"), ToggleDict(player4, "selectPlayer1Exile", True)]

                textbutton "Player 2" action [Show("player4_confirmScreens"), Hide("player4_ListSelect"), ToggleDict(player4, "selectPlayer2Exile", True)]
                
                textbutton "Player 3" action [Show("player4_confirmScreens"), Hide("player4_ListSelect"), ToggleDict(player4, "selectPlayer3Exile", True)]

screen player4_confirmScreens:
    if roles['Player 4'] == "Master Vampire" and readyToVote['Player 4'] == False:
        frame:
            xsize 600
            ysize 500
            # yoffset 557
            xoffset 1000
            background None
            has vbox

            if readyToVote['Player 4'] == False:
                
                if player4['selectplayer3Vampire'] == True:
                    text "Turn Player 3 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player4_minigame1"), Hide("player4_confirmScreens"), Notify("hi"), ToggleDict(player4, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player4_ListSelect"), Notify("NO!!!"), Hide("player4_confirmScreens"), ToggleDict(player4, "selectplayer3Vampire", False)]

                if player4['selectPlayer1Vampire'] == True:
                    text "Turn Player 1 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player4_minigame1"), Hide("player4_confirmScreens"), Notify("hi"), ToggleDict(player4, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player4_ListSelect"), Notify("NO!!!"), Hide("player4_confirmScreens"), ToggleDict(player4, "selectPlayer1Vampire", False)]

                if player4['selectPlayer4Vampire'] == True:
                    text "Turn Player 2 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player4_minigame1"), Hide("player4_confirmScreens"), Notify("hi"), ToggleDict(player4, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player4_ListSelect"), Notify("NO!!!"), Hide("player4_confirmScreens"), ToggleDict(player4, "selectPlayer2Vampire", False)]

    if readyToVote['Player 4'] == True:
        frame:
            xsize 600
            ysize 500
            yoffset 557
            xoffset 1000
            background None
            has vbox

            if player4['selectPlayer1Exile'] == True:
                text "Exile Player 2?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player4_confirmScreens"), Notify("hi"), SetVariable("playerTally1", playerTally1 + 1), ToggleDict(playersVoted, "Player 4", True)]

                    textbutton "No" action [Show("player4_ListSelect"), Notify("NO!!!"), Hide("player4_confirmScreens"), ToggleDict(player4, "selectPlayer1Exile", False)]

            if player4['selectPlayer2Exile'] == True:
                text "Exile Player 2?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player4_confirmScreens"), Notify("hi"), SetVariable("playerTally3", playerTally3 + 1), ToggleDict(playersVoted, "Player 4", True)]

                    textbutton "No" action [Show("player4_ListSelect"), Notify("NO!!!"), Hide("player4_confirmScreens"), ToggleDict(player4, "selectPlayer2Exile", False)]

            if player4['selectPlayer3Exile'] == True:
                text "Exile Player 3?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player4_confirmScreens"), Notify("hi"), SetVariable("playerTally3", playerTally3 + 1), ToggleDict(playersVoted, "Player 4", True)]

                    textbutton "No" action [Show("player4_ListSelect"), Notify("NO!!!"), Hide("player4_confirmScreens"), ToggleDict(player4, "selectPlayer3Exile", False)]

screen player4_minigame1:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 550 ypos 50
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player4_minigame2"), Hide("player4_minigame1")]

screen player4_minigame2:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 550 ypos 100
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player4_minigame3"), Hide("player4_minigame2")]

screen player4_minigame3:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 600 ypos 50
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player4_successTurning"), Hide("player4_minigame3")]

screen player4_successTurning:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset 1000
        background None
        has vbox

        if player4['selectPlayer3Vampire']:
            $ roles['Player 3'] = "Vampire"
            text "Successfully turned Player 3!" xoffset 50 yoffset 150

        if player4['selectplayer2Vampire']:
            $ roles['Player 2'] = "Vampire"
            text "Successfully turned Player 2!" xoffset 50 yoffset 150

        if player4['selectPlayer1Vampire']:
            $ roles['Player 1'] = "Vampire"
            text "Successfully turned Player 1!" xoffset 50 yoffset 150

        textbutton "End day." action [Show("endDayText"), Hide("player4_successTurning"), ToggleDict(endDayPlayers, "Player 3", True)] xoffset 225 yoffset 150 at buttonFadeIn


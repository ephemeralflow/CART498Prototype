screen playerTwoRole:
    frame:
        xsize 600
        ysize 500
        xoffset 1000
        # yoffset 200
        background None
        has vbox
        
        vbox:
            xoffset 225
            yoffset 200
            imagebutton:
                idle Solid("#FFF", xsize=128, ysize=64)
                hover Solid("#ff8303", xsize=128, ysize=64)
                action [Show("playerRole2"), Hide("playerTwoRole")]
            text "GET ROLE" size 24 color "#fff" 

screen playerRole2:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset 1000
        background None
        has vbox
        vbox:
            xoffset 225
            yoffset 200
            text "Your role is: [roles['Player 2']]" color "#fff" size 24 xoffset -100
            if roles['Player 2'] == "Guest":
                textbutton "Okay." action [Show("gameplayWalkplayer2"), Hide("playerRole2")]
            elif roles['Player 2'] == "Master Vampire":
                textbutton "Okay." action [Show("player2_ListSelect"), Hide("playerRole2")] #xoffset 0 yalign 0.65 

screen gameplayWalkplayer2:
    frame:
        xsize 600
        ysize 500
        xoffset 1250
        yoffset 250
        
        background None
        
        has vbox

        if player2Background == "#000080":
            text "Main Hub" xoffset -50
            hbox:
                textbutton "<-" action SetVariable("player2Background", "#800000") xoffset -200
                textbutton "->" action SetVariable("player2Background", "#00801c") xoffset 150
            textbutton "^\n |" action SetVariable("player2Background", "#804900") yoffset -300

        elif player2Background == "#800000":
            text "Left Wing" xoffset -50
            textbutton "->" action SetVariable("player2Background", "#000080") xoffset 200
            
        elif player2Background == "#00801c":
            text "Right Wing" xoffset -50
            textbutton "<-" action SetVariable("player2Background", "#000080") xoffset -200

        elif player2Background == "#804900":
            text "Balcony" xoffset -50
            textbutton "|\nv" action SetVariable("player2Background", "#000080") yoffset 100

screen player2_ListSelect:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset 1000
        background None
        has vbox

        vbox:
            xoffset 225
            yoffset 150

            if readyToVote['Player 2'] == False:
                textbutton "Player 1" action [Show("player2_confirmScreens"), Hide("player2_ListSelect"), ToggleDict(player2, "selectPlayer1Vampire", True)]

                textbutton "Player 3" action [Show("player2_confirmScreens"), Hide("player2_ListSelect"), ToggleDict(player2, "selectPlayer3Vampire", True)]
                
                textbutton "Player 4" action [Show("player2_confirmScreens"), Hide("player2_ListSelect"), ToggleDict(player2, "selectPlayer4Vampire", True)]

            if readyToVote['Player 2'] == True:
                textbutton "Player 1" action [Show("player2_confirmScreens"), Hide("player2_ListSelect"), ToggleDict(player2, "selectPlayer1Exile", True)]

                textbutton "Player 3" action [Show("player2_confirmScreens"), Hide("player2_ListSelect"), ToggleDict(player2, "selectPlayer3Exile", True)]
                
                textbutton "Player 4" action [Show("player2_confirmScreens"), Hide("player2_ListSelect"), ToggleDict(player2, "selectPlayer4Exile", True)]

screen player2_confirmScreens:
    if roles['Player 2'] == "Master Vampire" and readyToVote['Player 2'] == False:
        frame:
            xsize 600
            ysize 500
            # yoffset 557
            xoffset 1000
            background None
            has vbox

            if readyToVote['Player 2'] == False:
                
                if player2['selectPlayer3Vampire'] == True:
                    text "Turn Player 3 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player2_minigame1"), Hide("player2_confirmScreens"), Notify("hi"), ToggleDict(player2, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player2_ListSelect"), Notify("NO!!!"), Hide("player2_confirmScreens"), ToggleDict(player2, "selectPlayer3Vampire", False)]

                if player2['selectPlayer1Vampire'] == True:
                    text "Turn Player 1 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player2_minigame1"), Hide("player2_confirmScreens"), Notify("hi"), ToggleDict(player2, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player2_ListSelect"), Notify("NO!!!"), Hide("player2_confirmScreens"), ToggleDict(player2, "selectPlayer1Vampire", False)]

                if player2['selectPlayer4Vampire'] == True:
                    text "Turn Player 4 into a vampire?" xoffset 50 yoffset 150
                    hbox:
                        xoffset 225
                        yoffset 150

                        textbutton "Yes" action [Show("player2_minigame1"), Hide("player2_confirmScreens"), Notify("hi"), ToggleDict(player2, "selectVampireTurnAttempt", True)]

                        textbutton "No" action [Show("player2_ListSelect"), Notify("NO!!!"), Hide("player2_confirmScreens"), ToggleDict(player2, "selectPlayer4Vampire", False)]

    if readyToVote['Player 2'] == True:
        frame:
            xsize 600
            ysize 500
            # yoffset 557
            xoffset 1000
            background None
            has vbox

            if player2['selectPlayer1Exile'] == True:
                text "Exile Player 1?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player2_confirmScreens"), Notify("hi"), SetVariable("playerTally1", playerTally1 + 1), ToggleDict(playersVoted, "Player 2", True)]

                    textbutton "No" action [Show("player2_ListSelect"), Notify("NO!!!"), Hide("player2_confirmScreens"), ToggleDict(player2, "selectPlayer1Exile", False)]

            if player2['selectPlayer3Exile'] == True:
                text "Exile Player 3?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player2_confirmScreens"), Notify("hi"), SetVariable("playerTally3", playerTally3 + 1), ToggleDict(playersVoted, "Player 2", True)]

                    textbutton "No" action [Show("player2_ListSelect"), Notify("NO!!!"), Hide("player2_confirmScreens"), ToggleDict(player2, "selectPlayer3Exile", False)]

            if player2['selectPlayer4Exile'] == True:
                text "Exile Player 4?" xoffset 180 yoffset 150
                hbox:
                    xoffset 225
                    yoffset 150

                    textbutton "Yes" action [Show("endOfDate"), Hide("player2_confirmScreens"), Notify("hi"), SetVariable("playerTally4", playerTally4 + 1), ToggleDict(playersVoted, "Player 2", True)]

                    textbutton "No" action [Show("player2_ListSelect"), Notify("NO!!!"), Hide("player2_confirmScreens"), ToggleDict(player2, "selectPlayer4Exile", False)]

screen player2_minigame1:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 550 ypos 50
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player2_minigame2"), Hide("player2_minigame1")]

screen player2_minigame2:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 550 ypos 100
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player2_minigame3"), Hide("player2_minigame2")]

screen player2_minigame3:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset -100
        background None
        has vbox

        imagebutton:
            xpos 600 ypos 50
            idle Solid("#FFF", xsize=64, ysize=64)
            hover Solid("#ff8303", xsize=64, ysize=64)
            action [Show("player2_successTurning"), Hide("player2_minigame3")]

screen player2_successTurning:
    frame:
        xsize 600
        ysize 500
        # yoffset 557
        xoffset 1000
        background None
        has vbox

        if player2['selectPlayer1Vampire']:
            $ roles['Player 1'] = "Vampire"
            text "Successfully turned Player 1!" xoffset 50 yoffset 150

        if player2['selectPlayer3Vampire']:
            $ roles['Player 3'] = "Vampire"
            text "Successfully turned Player 3!" xoffset 50 yoffset 150

        if player2['selectPlayer4Vampire']:
            $ roles['Player 4'] = "Vampire"
            text "Successfully turned Player 4!" xoffset 50 yoffset 150

        textbutton "End day." action [Show("endDayText"), Hide("player2_successTurning"), ToggleDict(endDayPlayers, "Player 3", True)] xoffset 225 yoffset 150 at buttonFadeIn


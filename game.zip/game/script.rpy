﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define e = Character("Eileen")

default letterHolding = {
    "Player 1": False,
    "Player 2": False,
    "Player 3": False,
    "Player 4": False
}

default framePlayer3 = {
    "xsize": "600",
    "ysize": "500",
    "yalign": "0.5",
    "background": None
}

transform buttonFadeIn:
    alpha 0.0
    pause 1.0
    linear 0.5 alpha 1.0

default letterHold1 = False
default letterHold2 = False
default letterHold3 = False
default letterHold4 = False

default gameStartPlayer1 = False
default gameStartPlayer2 = False
default gameStartPlayer3 = False
default gameStartPlayer4 = False

default player1 = {
    "selectVampireTurnAttempt": False,
    "selectVampireTurn": False,

    "selectPlayer3Vampire": False,
    "selectPlayer2Vampire": False,
    "selectPlayer4Vampire": False,

    "ready": False,

    "selectPlayer4Exile": False,
    "selectPlayer2Exile": False,
    "selectPlayer3Exile": False
}

default player2 = {
    "selectVampireTurnAttempt": False,
    "selectVampireTurn": False,

    "selectPlayer1Vampire": False,
    "selectPlayer3Vampire": False,
    "selectPlayer4Vampire": False,

    "ready": False,

    "selectPlayer1Exile": False,
    "selectPlayer3Exile": False,
    "selectPlayer4Exile": False
}

default player3 = {
    "selectVampireTurnAttempt": False,
    "selectVampireTurn": False,

    "selectPlayer1Vampire": False,
    "selectPlayer2Vampire": False,
    "selectPlayer4Vampire": False,
    
    "ready": False,

    "selectPlayer1Exile": False,
    "selectPlayer2Exile": False,
    "selectPlayer4Exile": False
}

default player4 = {
    "selectVampireTurnAttempt": False,
    "selectVampireTurn": False,

    "selectPlayer1Vampire": False,
    "selectPlayer2Vampire": False,
    "selectPlayer3Vampire": False,

    "ready": False,

    "selectPlayer1Exile": False,
    "selectPlayer2Exile": False,
    "selectPlayer3Exile": False
}

default roles = {
    "Player 1": "Guest",
    "Player 2": "Guest",
    "Player 3": "Guest",
    "Player 4": "Guest",
}

default endDayPlayers = {
    "Player 1": False,
    "Player 2": False,
    "Player 3": False,
    "Player 4": False
}

default readyToVote = {
    "Player 1": False,
    "Player 2": False,
    "Player 3": False,
    "Player 4": False
}

default playersVoted = {
    "Player 1": False,
    "Player 2": False,
    "Player 3": False,
    "Player 4": False
}

default playerTally1 = 0
default playerTally2 = 0
default playerTally3 = 0
default playerTally4 = 0

default player1SelectVampire = False
default player2SelectVampire = False
default player3SelectVampire = False
default player4SelectVampire = False

default player1SelectExile = False
default player2SelectExile = False
default player3SelectExile = False
default player4SelectExile = False

default player1Vampire = False
default player2Vampire = False
default player3Vampire = False
default player4Vampire = False

default player1Background = "#000080"
default player2Background = "#000080"
default player3Background = "#000080"
default player4Background = "#000080"

default vampireTurnAttempt = False

screen global_watcher():
    # Check every 0.1 seconds if the variable is True
    if store.vampireTurnAttempt:
        timer 0.1 action [
            SetVariable("vampireTurnAttempt", False), # Reset it safely
            Jump("hideAllScreens")                  # Cleanly jump to your label
        ]

# The game starts here.

label hideAllScreens:
    $ player1Background = "#000080"
    $ player2Background = "#000080"
    $ player3Background = "#000080"
    $ player4Background = "#000080"

    call screen playerScreens

    hide screen gameplayWalkPlayer1

    call screen endDayText

label start:

    $ roles = {name: "Guest" for name in roles}

    # $ chosenVampire = renpy.random.choice(list(roles.keys()))
    # $ roles[chosenVampire] = "Master Vampire"

    $ roles['Player 3'] = "Master Vampire"

    show screen global_watcher

    show screen mainScreenToggle

    call screen playerScreens

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene bg room

    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.

    show eileen happy

    # These display lines of dialogue.

    e "You've created a new Ren'Py game."

    

    "The secret killer is... [chosenVampire]!"

    e "Once you add a story, pictures, and music, you can release it to the world!"

    # This ends the game.

    return

screen playerScreens:
    grid 2 2:
        xalign 0.5
        yalign 0.5
        yoffset 0
        xspacing 50
        yspacing 35
        allow_underfull True

        frame:
            xsize 600
            ysize 500
            yalign 0.5
            background player1Background
            has vbox

            text "Player 1" yoffset 160 xoffset -200

            if gameStartPlayer1 == False:
                textbutton "Start Game" action [ToggleScreen("playerOneRole"), ToggleVariable("gameStartPlayer1", True)] xoffset 200 yoffset 200

            

        frame:
            xsize 600
            ysize 500
            yalign 0.5
            background player2Background
            has vbox

            text "Player 2" yoffset 160 xoffset 650

            if gameStartPlayer2 == False:
                textbutton "Start Game" action [ToggleScreen("playerTwoRole"), ToggleVariable("gameStartPlayer2", True)] xoffset 200 yoffset 200

           

        frame:
            xsize 600
            ysize 500
            yalign 0.5
            background player3Background

            text "Player 3" yoffset 160 xoffset -200

            if gameStartPlayer3 == False:
                textbutton "Start Game" action [ToggleScreen("playerThreeRole"), ToggleVariable("gameStartPlayer3", True)] xoffset 200 yoffset 200

        frame:
            xsize 600
            ysize 500
            yalign 0.5
            background player4Background
            has vbox

            text "Player 4" yoffset 160 xoffset 650

            if gameStartPlayer4 == False:
                textbutton "Start Game" action [ToggleScreen("playerFourRole"), ToggleVariable("gameStartPlayer4", True)] xoffset 200 yoffset 200

            

# screen playerOneRole:

#     vbox:
#         xoffset 550
#         yoffset 200
#         imagebutton:
#             idle Solid("#FFF", xsize=128, ysize=64)
#             hover Solid("#ff8303", xsize=128, ysize=64)
#             action [Show("PlayerRolesDisplay"), SetDict(letterHolding, "Player 1", True), Hide("playerOneRole")]
#         text "GET ROLE" size 24 color "#fff" 

screen PlayerRolesTemplate:
    if letterHolding["Player 1"]:
        hbox:
            text "Your role is: [roles['Player 1']]" color "#fff" size 24 yoffset 200 xoffset 500

    if letterHolding["Player 2"]:
        hbox:
            text "Your role is: [roles['Player 2']]" color "#fff" size 24 yoffset 200 xoffset 1200
            textbutton "Okay." action [With(dissolve), Return(), Hide("collectedItem")] xalign 0.5 yalign 0.65 at buttonFadeIn

    if letterHolding["Player 3"]:
        hbox:
            text "Your role is: [roles['Player 3']]" color "#fff" size 24 yoffset 750 xoffset 500

    if letterHolding["Player 4"]:
        hbox:
            text "Your role is: [roles['Player 4']]" color "#fff" size 24 yoffset 750 xoffset 1200

screen PlayerRolesDisplay:
    use PlayerRolesTemplate



# screen hold_three_seconds_example():
#     vbox:
#         align (0.5, 0.5)
#         spacing 20

#         # This timer only starts counting when is_held becomes True.
#         # It waits 3.0 seconds, runs the action, and does NOT repeat.
#         if letterHold1:
#             timer 3.0 action [Notify("Successfully held for 3 seconds!"), SetScreenVariable("letterHold1", False)]

#         # Visual indicator to show feedback
#         if letterHold1:
#             text "Holding... keep pressing!" xalign 0.5
#         else:
#             text "Ready" xalign 0.5

#         imagebutton:
#             xalign 0.5
#             # background "#0088cc"
#             idle Solid("#393e46", xsize=90, ysize=90) # Replace with icon artwork
#             hover Solid("#00adb5", xsize=90, ysize=90)
#             padding (20, 10)

#             # 1. Start the 3-second timer when pressed down
#             keysym 'mousedown_1'
#             action SetScreenVariable("letterHold1", True)

#             # 2. Cancel the timer instantly if released early
#             alternate_keysym 'mouseup_1'
#             alternate SetScreenVariable("letterHold1", False)

#             # 3. Cancel the timer instantly if the mouse drags off the button
#             unhovered SetScreenVariable("letterHold1", False)

#         text "Hold for 3 Seconds"
            
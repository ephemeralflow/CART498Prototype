﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define e = Character("Eileen")

default letterHolding = {
    "Player 1": False,
    "Player 2": False,
    "Player 3": False,
    "Player 4": False
}

default framePlayer3 = {
    "xsize": "600",
    "ysize": "500",
    "yalign": "0.5",
    "background": None
}

transform buttonFadeIn:
    alpha 0.0
    pause 1.0
    linear 0.5 alpha 1.0

default letterHold1 = False
default letterHold2 = False
default letterHold3 = False
default letterHold4 = False

default gameStartPlayer1 = False
default gameStartPlayer2 = False
default gameStartPlayer3 = False
default gameStartPlayer4 = False

default player1 = {
    "selectVampireTurnAttempt": False,
    "selectVampireTurn": False,

    "selectPlayer3Vampire": False,
    "selectPlayer2Vampire": False,
    "selectPlayer4Vampire": False,

    "ready": False,

    "selectPlayer4Exile": False,
    "selectPlayer2Exile": False,
    "selectPlayer3Exile": False
}

default player2 = {
    "selectVampireTurnAttempt": False,
    "selectVampireTurn": False,

    "selectPlayer1Vampire": False,
    "selectPlayer3Vampire": False,
    "selectPlayer4Vampire": False,

    "ready": False,

    "selectPlayer1Exile": False,
    "selectPlayer3Exile": False,
    "selectPlayer4Exile": False
}

default player3 = {
    "selectVampireTurnAttempt": False,
    "selectVampireTurn": False,

    "selectPlayer1Vampire": False,
    "selectPlayer2Vampire": False,
    "selectPlayer4Vampire": False,
    
    "ready": False,

    "selectPlayer1Exile": False,
    "selectPlayer2Exile": False,
    "selectPlayer4Exile": False
}

default player4 = {
    "selectVampireTurnAttempt": False,
    "selectVampireTurn": False,

    "selectPlayer1Vampire": False,
    "selectPlayer2Vampire": False,
    "selectPlayer3Vampire": False,

    "ready": False,

    "selectPlayer1Exile": False,
    "selectPlayer2Exile": False,
    "selectPlayer3Exile": False
}



default endDayPlayers = {
    "Player 1": False,
    "Player 2": False,
    "Player 3": False,
    "Player 4": False
}

default readyToVote = {
    "Player 1": False,
    "Player 2": False,
    "Player 3": False,
    "Player 4": False
}

default playersVoted = {
    "Player 1": False,
    "Player 2": False,
    "Player 3": False,
    "Player 4": False
}

default playerTally1 = 0
default playerTally2 = 0
default playerTally3 = 0
default playerTally4 = 0

default player1SelectVampire = False
default player2SelectVampire = False
default player3SelectVampire = False
default player4SelectVampire = False

default player1SelectExile = False
default player2SelectExile = False
default player3SelectExile = False
default player4SelectExile = False

default player1Vampire = False
default player2Vampire = False
default player3Vampire = False
default player4Vampire = False

# default player1Background = "#000080"
# default player2Background = "#000080"
# default player3Background = "#000080"
# default player4Background = "#000080"

default vampireTurnAttempt = False

screen global_watcher():
    # Check every 0.1 seconds if the variable is True
    if store.vampireTurnAttempt:
        timer 0.1 action [
            SetVariable("vampireTurnAttempt", False), # Reset it safely
            Jump("hideAllScreens")                  # Cleanly jump to your label
        ]

# The game starts here.

label hideAllScreens:
    $ player1Background = "#000080"
    $ player2Background = "#000080"
    $ player3Background = "#000080"
    $ player4Background = "#000080"

    call screen playerScreens

    hide screen gameplayWalkPlayer1

    call screen endDayText

init python:
    import random
    import time

    def start_vampire_minigame(attacker, target):
        global vampire_minigame_active, vampire_attacker, vampire_target, vampire_step, current_btn_pos
        vampire_attacker = attacker
        vampire_target = target
        players[attacker]["converting_target"] = target
        players[attacker]["showing_map"] = False
        
        # Mark that this vampire has used their bite action for this night!
        players[attacker]["has_bitten_this_night"] = True
        
        vampire_step = 1
        vampire_minigame_active = True
        current_btn_pos = (random.uniform(0.2, 0.8), random.uniform(0.3, 0.7))

    def handle_vampire_sequence_click():
        global vampire_step, vampire_minigame_active, current_btn_pos, vampire_target
        vampire_step += 1
        
        if vampire_step > 3:
            vampire_minigame_active = False
            # Store success status, but DO NOT convert role here yet!
            players[vampire_attacker]["minigame_completed"] = "success"
            
            # Check if everyone else is locked in so we can resolve the night
            check_round_completion()
        else:
            current_btn_pos = (random.uniform(0.2, 0.8), random.uniform(0.3, 0.7))

    def vampire_minigame_fail():
        global vampire_minigame_active
        if vampire_minigame_active:
            vampire_minigame_active = False
            players[vampire_attacker]["minigame_completed"] = "failure"
            check_round_completion()

    def start_exorcism_minigame(attacker, target):
        global priest_minigame_active, priest_attacker, priest_target, priest_step, priest_btn_pos, exorcism_result, priest_exorcism_ready, priest_exorcism_success
        priest_attacker = attacker
        priest_target = target
        players[attacker]["priest_target_to_confirm"] = None
        players[attacker]["showing_map"] = False
        
        priest_exorcism_ready = False
        priest_step = 1
        exorcism_result = None
        priest_exorcism_success = None
        priest_minigame_active = True
        priest_btn_pos = (random.uniform(0.2, 0.8), random.uniform(0.3, 0.7))

    def handle_exorcism_sequence_click():
        global priest_step, priest_minigame_active, exorcism_result, priest_btn_pos, priest_target, priest_exorcism_success, successfully_exorcised_player
        priest_step += 1
        
        if priest_step > 3:
            priest_minigame_active = False
            exorcism_result = "completed"
            
            if random.random() < 0.5:
                priest_exorcism_success = True
                successfully_exorcised_player = priest_target  # Track who was successfully cleansed!
            else:
                priest_exorcism_success = False
                
            check_round_completion()
        else:
            priest_btn_pos = (random.uniform(0.2, 0.8), random.uniform(0.3, 0.7))

    def exorcism_minigame_fail():
        global priest_minigame_active, exorcism_result, priest_exorcism_success
        if priest_minigame_active:
            priest_minigame_active = False
            exorcism_result = "completed"
            priest_exorcism_success = False
            check_round_completion()

    def process_exorcism_reversion():
        global priest_exorcism_success, priest_target
        if priest_exorcism_success and priest_target:
            target_data = players[priest_target]
            if target_data["role"] == "Vampire" and not target_data.get("is_master", False):
                # Restore original pre-converted role (or Guest if none saved)
                restored_role = target_data.get("original_role", "Guest")
                if not restored_role:
                    restored_role = "Guest"
                    
                target_data["role"] = restored_role
                target_data["original_role"] = None
        
        priest_exorcism_success = None

    def lock_player_room(player_name):
        players[player_name]["room_locked"] = True
        check_round_completion()

    def confirm_priest_prayer(player_name):
        global priest_exorcism_ready
        players[player_name]["priest_action_choice"] = "pray"
        priest_exorcism_ready = True  # Priest prays, making exorcism ready for the next round!
        lock_player_room(player_name)

    def lock_player_room(player_name):
        players[player_name]["room_locked"] = True
        check_round_completion()

    def check_round_completion():
        global bite_result, night_phase_step, room_selection_phase, priest_protected_target
        
        # 1. Check if all non-exiled players have locked their rooms
        all_locked = True
        for p_key, p_data in players.items():
            if p_data["role"] != "Exiled" and not p_data.get("room_locked", False):
                all_locked = False
                break
                
        if not all_locked:
            return

        # 2. Check Priest Protection Action
        priest_key = None
        for p_k, p_d in players.items():
            if p_d["role"] == "Priest" and p_d["role"] != "Exiled":
                priest_key = p_k
                break

        priest_protected_target = None
        if priest_key:
            p_action = players[priest_key].get("priest_action_choice")
            if p_action == "protect":
                priest_protected_target = players[priest_key].get("priest_target")

        # 3. Find the Master Vampire
        master_vampire_key = None
        for p_key, p_data in players.items():
            if p_data["role"] == "Vampire" and p_data["is_master"] and p_data["role"] != "Exiled":
                master_vampire_key = p_key
                break
                
        if not master_vampire_key:
            bite_result = "failure"
            night_phase_step = 0
            room_selection_phase = False
            return

        vamp_data = players[master_vampire_key]
        target = vamp_data.get("converting_target")
        
        if target == "Skip":
            bite_result = "failure"
            night_phase_step = 0
            room_selection_phase = False
            return

        minigame_status = vamp_data.get("minigame_completed", None)
        if minigame_status is None:
            return

        if minigame_status == "success":
            if target == priest_protected_target:
                bite_result = "protected"
            else:
                bite_result = "success"

                target_data = players[target]
                if "original_role" not in target_data or target_data["original_role"] is None:
                    target_data["original_role"] = target_data["role"]
                
                target_data["role"] = "Vampire"
                
                check_win_conditions()
        else:
            bite_result = "failure"

        night_phase_step = 0
        room_selection_phase = False

    def reset_room_locks():
        global exorcism_result, priest_exorcism_success, successfully_exorcised_player
        
        process_exorcism_reversion()
        
        for p in players.values():
            p["room_locked"] = False
            p["vampire_target_to_confirm"] = None
            p["converting_target"] = None
            p["minigame_completed"] = None
            p["priest_action_choice"] = None
            p["priest_target"] = None
            p["has_bitten_this_night"] = False
        
        exorcism_result = None
        priest_exorcism_success = None
        successfully_exorcised_player = None  # Reset for the new round
        
        check_win_conditions()

    def check_all_rooms_finished():
        global room_selection_phase
        all_locked = True
        for p_key, p_data in players.items():
            if p_data["role"] != "Exiled" and not p_data.get("room_locked", False):
                all_locked = False
                break
        if all_locked:
            room_selection_phase = False

    def reset_all_exile_votes():
        for p in players.values():
            p["exile_target"] = None
            p["exile_confirmed"] = False

    def process_exile_votes():
        global exile_results_active, exiled_player_result
        
        # PROCESS ANY PENDING EXORCISM REVERSIONS FIRST!
        process_exorcism_reversion()
        
        vote_counts = {}
        for p_key, p_data in players.items():
            target = p_data.get("exile_target")
            # ONLY count valid player names as actual votes (explicitly ignore None and "None")
            if target and target != "None" and target in players:
                vote_counts[target] = vote_counts.get(target, 0) + 1
                
        if not vote_counts:
            exiled_player_result = "None"
        else:
            max_votes = max(vote_counts.values())
            top_candidates = [p for p, count in vote_counts.items() if count == max_votes]
            
            # A tie only happens if two or more actual players share the exact same highest vote count
            if len(top_candidates) > 1:
                exiled_player_result = "None"
            else:
                exiled_player_result = top_candidates[0]
                
        exile_results_active = True

    def handle_exile_result_cleanup():
        global exile_results_active, exile_phase_active, bite_result, night_phase_step
        if exiled_player_result and exiled_player_result != "None":
            players[exiled_player_result]["role"] = "Exiled"
            
        exile_results_active = False
        exile_phase_active = False
        bite_result = None
        night_phase_step = 0
        reset_all_exile_votes()
        reset_room_locks()
        
        # Reset the once-per-night bite restriction for the brand new night cycle after exile!
        for p_data in players.values():
            p_data["has_bitten_this_night"] = False
        
        # Check if win condition met after exile
        check_win_conditions()

    def check_win_conditions():
        global game_over_state
        
        # Check active (non-exiled) players
        surviving_players = [p for p in players.values() if p["role"] != "Exiled"]
        if not surviving_players:
            return
            
        all_vampires = all(p["role"] == "Vampire" for p in surviving_players)
        
        # Check if ANY vampire still exists anywhere in the game (even if exiled, or check surviving ones)
        any_vampire_alive = any(p["role"] == "Vampire" for p in players.values() if p["role"] != "Exiled")
        
        if all_vampires:
            game_over_state = "vampire_win"
        elif not any_vampire_alive:
            game_over_state = "hunters_win"

    def restart_game_loop():
        global game_over_state, bite_result, night_phase_step, exile_phase_active, exile_results_active
        game_over_state = None
        bite_result = None
        night_phase_step = 0
        exile_phase_active = False
        exile_results_active = False
        reset_room_locks()
        reset_all_exile_votes()
        renpy.jump("start")
        director_started = False
        director_letters_opened = False

        for p_data in players.values():
            p_data["role"] = "Guest"
            p_data["roles_revealed"] = False  # This ensures the letters are un-opened again
            p_data["players_ready"] = False
            p_data["location"] = "Main Hub"
            p_data["showing_map"] = False
            p_data["room_locked"] = False
            p_data["exile_target"] = None
            p_data["exile_confirmed"] = False

# Room Selection and Night Action States
default room_selection_phase = False
default player_rooms_locked = False
default map_controls_unlocked = False

# Game Over / Victory State
default game_over_state = None

# Vampire Minigame States
default vampire_minigame_active = False
default vampire_attacker = None
default vampire_target = None
default vampire_step = 1
default current_btn_pos = (0.5, 0.5)
default bite_result = None

# Priest Action States
default priest_action_choice = None       # "protect" or "exorcise" or None
default priest_target = None              # Selected target for protect/exorcise
default priest_target_to_confirm = None   # Confirmation popup tracker
default priest_minigame_active = False
default priest_attacker = None
default priest_step = 1
default priest_btn_pos = (0.5, 0.5)
default exorcism_result = None            # "success" or "failure" or None
default priest_protected_target = None    # Tracks who is protected for the current night
default priest_exorcism_ready = False  # Set to True when Priest prays, allowing exorcism next round
default priest_exorcism_success = None

# Exile Voting Results State
default exile_phase_active = False
default exile_results_active = False
default exiled_player_result = None
default all_exiles_voted = False
default successfully_exorcised_player = None

default director_started = False
default director_letters_opened = False

# Controls when ready buttons appear across all cards
default all_can_ready = False

transform smooth_fade_in:
    alpha 0.0
    linear 0.8 alpha 1.0

transform shake_effect:
    linear 0.05 xoffset -6
    linear 0.05 xoffset 6
    linear 0.05 xoffset -6
    linear 0.05 xoffset 6
    linear 0.05 xoffset -3
    linear 0.05 xoffset 3
    linear 0.05 xoffset 0

# Player Dictionary Template
default players = {
    "Player 1": {
        "role": "Guest",
        "roles_revealed": False,
        "role_text_shown": False,
        "players_ready": False,
        "location": "Main Hub",
        "showing_map": False,
        "converting_target": None,
        "vampire_target_to_confirm": None,
        "exile_target": None,
        "exile_confirmed": False,
        "is_master": False,
        "room_locked": False,
        "showing_map": False
    },
    "Player 2": {
        "role": "Guest",
        "roles_revealed": False,
        "role_text_shown": False,
        "players_ready": False,
        "location": "Main Hub",
        "showing_map": False,
        "converting_target": None,
        "vampire_target_to_confirm": None,
        "exile_target": None,
        "exile_confirmed": False,
        "is_master": False,
        "room_locked": False,
        "showing_map": False
    },
    "Player 3": {
        "role": "Guest",
        "roles_revealed": False,
        "role_text_shown": False,
        "players_ready": False,
        "location": "Main Hub",
        "showing_map": False,
        "converting_target": None,
        "vampire_target_to_confirm": None,
        "exile_target": None,
        "exile_confirmed": False,
        "is_master": False,
        "room_locked": False,
        "showing_map": False
    },
    "Player 4": {
        "role": "Guest",
        "roles_revealed": False,
        "role_text_shown": False,
        "players_ready": False,
        "location": "Main Hub",
        "showing_map": False,
        "converting_target": None,
        "vampire_target_to_confirm": None,
        "exile_target": None,
        "exile_confirmed": False,
        "is_master": False,
        "room_locked": False,
        "showing_map": False
    },
}

# Map position trackers for all 4 players
default player1Background = "#000080"
default player2Background = "#000080"
default player3Background = "#000080"
default player4Background = "#000080"

label assign_roles:
    # 1. Reset all players back to "Guest"
    $ roles["Player 1"] = "Guest"
    $ roles["Player 2"] = "Guest"
    $ roles["Player 3"] = "Guest"
    $ roles["Player 4"] = "Guest"

    # 2. Randomly pick 3 distinct players from your dictionary keys
    $ chosen_players = renpy.random.sample(list(roles.keys()), 3)

    # 3. Assign the roles to the chosen players by index
    $ roles[chosen_players[0]] = "Vampire"
    $ roles[chosen_players[1]] = "Cultist"
    $ roles[chosen_players[2]] = "Inquisitor"

    $ p1_role = roles["Player 1"]
    $ p2_role = roles["Player 2"]
    $ p3_role = roles["Player 3"]
    $ p4_role = roles["Player 4"]

    "Roles have been randomly assigned!"
    return

label main_menu:
    return

label possibleLoop:
    python:
        import random
        import time

        random.seed(time.time())

        for p in players:
            players[p]["role"] = "Guest"
            players[p]["roles_revealed"] = False
            players[p]["role_text_shown"] = False
            players[p]["players_ready"] = False
            players[p]["location"] = "Main Hub"
            players[p]["showing_map"] = False
            players[p]["converting_target"] = None
            players[p]["exile_target"] = None
            players[p]["exile_confirmed"] = False
            players[p]["is_master"] = False
            players[p]["vampire_target_to_confirm"] = None

        # Exorcist replaced with Priest
        secret_roles = ["Vampire", "Cultist", "Priest"]
        chosen_players = random.sample(list(players.keys()), len(secret_roles))
        
        for p, r in zip(chosen_players, secret_roles):
            players[p]["role"] = r

        # Designate the Master Vampire
        for p_key, p_data in players.items():
            if p_data["role"] == "Vampire":
                p_data["is_master"] = True
                break

    $ all_can_ready = False
    $ map_controls_unlocked = False
    $ game_over_state = None
    $ bite_result = None
    $ night_phase_step = 0
    $ exile_phase_active = False
    $ exile_results_active = False

    # "Roles have been assigned. Review your roles when ready."

    show screen information_button
    show screen role_grid_screen
    
    call screen main_television

    # show screen live_vampire_counter
    

label next_game_phase:
    "Everyone is ready! Proceeding with the game..."
    return

label start:

    # "hi"
    scene background
    # show redspace
    # "BRO"

    call possibleLoop

    "hi"

    call assign_roles 

    python:
        import random

        # 1. Reset all roles to "Guest" and states back to False
        for p in players:
            players[p]["role"] = "Guest"
            players[p]["roles_revealed"] = False
            players[p]["players_ready"] = False

        # 2. Assign secret roles
        secret_roles = ["Vampire", "Cultist", "Inquisitor"]
        chosen_players = renpy.random.sample(list(players.keys()), len(secret_roles))
        
        for p, r in zip(chosen_players, secret_roles):
            players[p]["role"] = r

    $ all_can_ready = False

    "Roles have been assigned. Review your roles when ready."

    call screen role_grid_screen

    "hi"

label next_game_phase1:
    "Everyone is ready! Transitioning to the next screen or phase..."
    return

    # $ roles = {name: "Guest" for name in roles}

    # $ chosenVampire = renpy.random.choice(list(roles.keys()))
    # $ roles[chosenVampire] = "Master Vampire"

    # $ roles['Player 3'] = "Master Vampire"

    show screen global_watcher

    show screen mainScreenToggle

    call screen role_grid_screen

    # Show a background. This uses a placeholder by default, but you can
    # add a file (named either "bg room.png" or "bg room.jpg") to the
    # images directory to show it.

    scene bg room

    # This shows a character sprite. A placeholder is used, but you can
    # replace it by adding a file named "eileen happy.png" to the images
    # directory.

    show eileen happy

    # These display lines of dialogue.

    e "You've created a new Ren'Py game."

    

    "The secret killer is... [chosenVampire]!"

    e "Once you add a story, pictures, and music, you can release it to the world!"

    # This ends the game.

    return

screen playerScreens:
    grid 2 2:
        xalign 0.5
        yalign 0.5
        yoffset 0
        xspacing 50
        yspacing 35
        allow_underfull True

        frame:
            xsize 600
            ysize 500
            yalign 0.5
            background player1Background
            has vbox

            text "Player 1" yoffset 160 xoffset -200

            if gameStartPlayer1 == False:
                textbutton "Start Game" action [ToggleScreen("playerOneRole"), ToggleVariable("gameStartPlayer1", True)] xoffset 200 yoffset 200

            

        frame:
            xsize 600
            ysize 500
            yalign 0.5
            background player2Background
            has vbox

            text "Player 2" yoffset 160 xoffset 650

            if gameStartPlayer2 == False:
                textbutton "Start Game" action [ToggleScreen("playerTwoRole"), ToggleVariable("gameStartPlayer2", True)] xoffset 200 yoffset 200

           

        frame:
            xsize 600
            ysize 500
            yalign 0.5
            background player3Background

            text "Player 3" yoffset 160 xoffset -200

            if gameStartPlayer3 == False:
                textbutton "Start Game" action [ToggleScreen("playerThreeRole"), ToggleVariable("gameStartPlayer3", True)] xoffset 200 yoffset 200

        frame:
            xsize 600
            ysize 500
            yalign 0.5
            background player4Background
            has vbox

            text "Player 4" yoffset 160 xoffset 650

            if gameStartPlayer4 == False:
                textbutton "Start Game" action [ToggleScreen("playerFourRole"), ToggleVariable("gameStartPlayer4", True)] xoffset 200 yoffset 200

            

# screen playerOneRole:

#     vbox:
#         xoffset 550
#         yoffset 200
#         imagebutton:
#             idle Solid("#FFF", xsize=128, ysize=64)
#             hover Solid("#ff8303", xsize=128, ysize=64)
#             action [Show("PlayerRolesDisplay"), SetDict(letterHolding, "Player 1", True), Hide("playerOneRole")]
#         text "GET ROLE" size 24 color "#fff" 

screen PlayerRolesTemplate:
    if letterHolding["Player 1"]:
        hbox:
            text "Your role is: [roles['Player 1']]" color "#fff" size 24 yoffset 200 xoffset 500

    if letterHolding["Player 2"]:
        hbox:
            text "Your role is: [roles['Player 2']]" color "#fff" size 24 yoffset 200 xoffset 1200
            textbutton "Okay." action [With(dissolve), Return(), Hide("collectedItem")] xalign 0.5 yalign 0.65 at buttonFadeIn

    if letterHolding["Player 3"]:
        hbox:
            text "Your role is: [roles['Player 3']]" color "#fff" size 24 yoffset 750 xoffset 500

    if letterHolding["Player 4"]:
        hbox:
            text "Your role is: [roles['Player 4']]" color "#fff" size 24 yoffset 750 xoffset 1200

screen PlayerRolesDisplay:
    use PlayerRolesTemplate



# screen hold_three_seconds_example():
#     vbox:
#         align (0.5, 0.5)
#         spacing 20

#         # This timer only starts counting when is_held becomes True.
#         # It waits 3.0 seconds, runs the action, and does NOT repeat.
#         if letterHold1:
#             timer 3.0 action [Notify("Successfully held for 3 seconds!"), SetScreenVariable("letterHold1", False)]

#         # Visual indicator to show feedback
#         if letterHold1:
#             text "Holding... keep pressing!" xalign 0.5
#         else:
#             text "Ready" xalign 0.5

#         imagebutton:
#             xalign 0.5
#             # background "#0088cc"
#             idle Solid("#393e46", xsize=90, ysize=90) # Replace with icon artwork
#             hover Solid("#00adb5", xsize=90, ysize=90)
#             padding (20, 10)

#             # 1. Start the 3-second timer when pressed down
#             keysym 'mousedown_1'
#             action SetScreenVariable("letterHold1", True)

#             # 2. Cancel the timer instantly if released early
#             alternate_keysym 'mouseup_1'
#             alternate SetScreenVariable("letterHold1", False)

#             # 3. Cancel the timer instantly if the mouse drags off the button
#             unhovered SetScreenVariable("letterHold1", False)

#         text "Hold for 3 Seconds"
            